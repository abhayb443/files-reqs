"""EDocService URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.urls import path,include
from django.conf import settings

admin.site.site_header = "EDocService-Admin"
admin.site.site_title = "EDS-Admin"
admin.site.index_title = "E-Doc Service"

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include('useraccounts.urls')),
    path('document_upload',include('ocr_engine.urls')),
    path('text_match',include('text_match.urls')),
    path('document_classification',include('document_classification.urls')),
    path('face_match',include('face_match.urls')),
    path('liveliness_check',include('liveliness_check.urls')),
    path('fraud_detection',include('fraud_detection.urls')),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
else:
    urlpatterns += staticfiles_urlpatterns()