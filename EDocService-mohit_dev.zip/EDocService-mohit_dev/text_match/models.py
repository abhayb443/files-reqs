from django.contrib.auth.models import User
from django.db import models
from django.db.models import UniqueConstraint


class UserTextMatch(models.Model):
    TM_Id = models.AutoField(primary_key=True)
    userId = models.ForeignKey(User, on_delete=models.CASCADE)
    inputString1 = models.TextField()
    inputString2 = models.TextField()
    matchResult  = models.CharField(max_length=25,default='NOT SET')
    matchPercentage = models.IntegerField()
    to_be_reviewed = models.TextField(default='N/A')
    TextCreatedDateTime = models.DateTimeField(auto_now_add=True)

    class Meta:
        UniqueConstraint(fields=['TM_Id', 'userId'], name='TextMatch_Unique_Recordset')

    def __str__(self):
        return 'UserId:{}|Text1:{}|Text2:{}'.format(self.userId,self.inputString1[:5],self.inputString2[:5])
