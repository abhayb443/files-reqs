from django.urls import path
from text_match import views

urlpatterns = [
    path('', views.TextMatchView.as_view(),name="text_match"),

]