from django.contrib import messages
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.views import View
from text_match.models import UserTextMatch
from useraccounts.models import UserProfileExtension
import requests


class TextMatchView(View):

    def getUserAvatar(self, userID):
        UserAvatars = UserProfileExtension.objects.values('avatar').filter(user_id=userID)
        try:
            UserAvatar = UserAvatars[0].get('avatar')
        except:
            UserAvatar = 'avatar/default.png'
        return UserAvatar

    def performTextMatching(self,request,reqPayload):
        endpoint = "https://1e66a0d6-659a-4ebc-b0f8-3f33787d01a6.mock.pstmn.io/documents_ml/v1/text_matching"
        try:
            response = requests.request('POST', endpoint, data=reqPayload)
            # print(response.status_code)
            jsonResp = response.json()
            if response.status_code == 200:
                if jsonResp.get('data').get('is_name_match') == 'yes':
                    result = {
                        "match_result":'STRING MATCHED',
                        "match_percentage":jsonResp.get('data').get('name_match_percentage'),
                        "to_be_reviewed":jsonResp.get('data').get('to_be_reviewed').upper()
                    }
                else:
                    result = {
                        "match_result": 'STRING NOT MATCHED',
                        "match_percentage": jsonResp.get('data').get('name_match_percentage'),
                        "to_be_reviewed": jsonResp.get('data').get('to_be_reviewed').upper()
                    }
                #print(result)
            else:
                print(jsonResp)
                result = {"status":"FAILURE"}

        except Exception as error:
               messages.warning(request, "Error occured while processing data.")
               print(error)
               result = {"status":"FAILURE"}
        return result


    def textMatcher(self,request):
        textString1 = request.POST.get('textMatchStr1')
        textString2 = request.POST.get('textMatchStr2')
        user = User.objects.get(id=request.user.id)

        try:
            userTxtMtch = UserTextMatch()
            userTxtMtch.userId=user
            userTxtMtch.inputString1=textString1
            userTxtMtch.inputString2=textString2

            '''
            #Adding Mock API call for testing:
            response = requests.request('GET','http://127.0.0.1:5000/textMatch/'+str(textString1)+'/'+str(textString2))
            jsonResp = response.json()
            #print(jsonResp)
            result = jsonResp.get('matchResult')
            '''
            #Adding integration logic for Mock API, call to function
            requestPayload={
                            "primary_string": textString1,
                            "string_to_match": textString2
                           }

            textMatchResult = self.performTextMatching(request,requestPayload)
            userTxtMtch.matchResult=textMatchResult.get('match_result')
            userTxtMtch.matchPercentage = textMatchResult.get('match_percentage')
            userTxtMtch.to_be_reviewed = textMatchResult.get('to_be_reviewed')
            userTxtMtch.save()

        except Exception as error:
            messages.warning(request, "Failed to process data:{}".format(error))

        return textMatchResult

    def get(self,request):
        if request.user.is_anonymous:
            return redirect('/login')
        UserAvatar = self.getUserAvatar(request.user.id)
        return render(request, 'text_match.html', {'UserAvatar': UserAvatar})

    def post(self,request):
        if request.user.is_anonymous:
            return redirect('/login')
        UserAvatar = self.getUserAvatar(request.user.id)
        textMatchResult = self.textMatcher(request)
        return render(request, 'text_match.html', {'UserAvatar': UserAvatar,'textMatchResult':textMatchResult})
