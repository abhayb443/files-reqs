from django.contrib import admin
from text_match.models import UserTextMatch
# Register your models here.
admin.site.register(UserTextMatch)
