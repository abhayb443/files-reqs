from django.contrib import admin
from liveliness_check.models import UserFaceLivelinessCheck
# Register your models here.
admin.site.register(UserFaceLivelinessCheck)