import requests
from django.contrib import messages
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.views import View
from liveliness_check.models import UserFaceLivelinessCheck
from useraccounts.models import UserProfileExtension


class UserFaceLiveCheckView(View):

    def getUserAvatar(self, userID):
        UserAvatars = UserProfileExtension.objects.values('avatar').filter(user_id=userID)
        try:
            UserAvatar = UserAvatars[0].get('avatar')
        except:
            UserAvatar = 'avatar/default.png'
        return UserAvatar

    def performLivelinessCheck(self,reqPayload,request,faceLiveId):
        endpoint="https://1e66a0d6-659a-4ebc-b0f8-3f33787d01a6.mock.pstmn.io/documents_ml/v1/check_live_photo"
        try:
            response=requests.request('POST',endpoint,data=reqPayload)
            respJson=response.json()
            if response.status_code == 200:
                LivelinessCheckData = {
                    'LivlinessCheckResult':respJson.get('data').get('photo-liveness').upper(),
                    'LivlinessConfidence':respJson.get('data').get('confidence')
                }

                # Updating existing record in backend:
                LivlinessCheckResult = LivelinessCheckData.get('LivlinessCheckResult')
                LivelinessCheckConfidence = LivelinessCheckData.get('LivlinessConfidence')
                UserFaceLivelinessCheck.objects.filter(userId=request.user.id,faceLivelinessId=faceLiveId).update(faceLivelinessResult=LivlinessCheckResult,faceLivelinessConfidence=LivelinessCheckConfidence)

            else:
                LivelinessCheckData={"status":"FAILURE"}
                print(respJson)

        except Exception as error:
            print(respJson)
            print(error)
            LivelinessCheckData={"status":"FAILURE"}
            messages.warning(request, "Failed to contact Server!")

        return LivelinessCheckData


    def FaceLiveChecker(self,request):
        ImgOrVidLoc =  request.FILES.get('FaceLiveFile')
        user = User.objects.get(id=request.user.id)

        try:
            FaceLiveCheckObj = UserFaceLivelinessCheck()
            FaceLiveCheckObj.userId = user
            FaceLiveCheckObj.ImgOrVidLoc = ImgOrVidLoc
            #FaceLiveCheckObj.faceLivelinessResult=''
            FaceLiveCheckObj.save()
            messages.success(request, "User's picture has been successfully uploaded!")

            # Data retrival post insertion for API call
            LatestInsertedRecordValues = UserFaceLivelinessCheck.objects.filter(userId=request.user.id).values('faceLivelinessId','ImgOrVidLoc',).order_by('-CreatedDateTime')[:1]
            # print(LatestInsertedRecordQs)
            # Setting up data inputs
            UploadedFaceLiveId = LatestInsertedRecordValues[0].get('faceLivelinessId')
            UploadedFaceImgOrVid = 'media/'+LatestInsertedRecordValues[0].get('ImgOrVidLoc')

            #print(UploadedFaceLiveId,UploadedFaceImgOrVid)
            # Preparing for API call:
            requestPayload = {
                "file": UploadedFaceImgOrVid
            }

            LivlinessCheckData = self.performLivelinessCheck(requestPayload,request,UploadedFaceLiveId)
            #print(LivlinessCheckData)


        except Exception as error:
            LivlinessCheckData={"status":"FAILURE"}
            messages.warning(request, "Failed to process data:{}".format(error))

        return LivlinessCheckData


    def get(self,request):
        if request.user.is_anonymous:
            return redirect('/login')
        UserAvatar = self.getUserAvatar(request.user.id)
        return render(request, 'liveliness_check.html', {'UserAvatar': UserAvatar})

    def post(self,request):
        if request.user.is_anonymous:
            return redirect('/login')
        UserAvatar = self.getUserAvatar(request.user.id)
        result = self.FaceLiveChecker(request)
        return render(request, 'liveliness_check.html', {'UserAvatar': UserAvatar,'result':result})