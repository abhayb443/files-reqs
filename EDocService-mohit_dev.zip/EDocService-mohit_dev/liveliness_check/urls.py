from django.urls import path
from liveliness_check import views

urlpatterns = [
    path('', views.UserFaceLiveCheckView.as_view(),name="liveliness_check"),
]