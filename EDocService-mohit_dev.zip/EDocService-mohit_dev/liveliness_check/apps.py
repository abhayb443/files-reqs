from django.apps import AppConfig


class LivelinessCheckConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'liveliness_check'
