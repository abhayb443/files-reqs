from django.contrib.auth.models import User
from django.db import models
from django.db.models import UniqueConstraint


class UserFaceLivelinessCheck(models.Model):
    faceLivelinessId = models.AutoField(primary_key=True)
    userId = models.ForeignKey(User,on_delete=models.CASCADE)
    ImgOrVidLoc = models.FileField(upload_to='uploaded_livliness_check')
    faceLivelinessResult = models.CharField(max_length=25, default='NOT SET')
    faceLivelinessConfidence = models.FloatField(default=0.0)
    CreatedDateTime = models.DateTimeField(auto_now_add=True)

    class Meta:
        UniqueConstraint(fields=['faceLivelinessId', 'userId'], name='FaceLivelinessCheck_Unique_Recordset')

    def __str__(self):
        return 'UserId:{}|Selfie:{}'.format(self.userId,self.ImgOrVidLoc)
