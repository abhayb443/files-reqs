from django.contrib.auth.models import User
from django.db import models
from django.db.models import UniqueConstraint


class UserDocuments(models.Model):
    docId = models.AutoField(primary_key=True)
    userId = models.ForeignKey(User,on_delete=models.CASCADE)
    documentType = models.CharField(max_length=20)
    documentLoc = models.ImageField(upload_to='uploaded_documents')
    extractedName = models.CharField(max_length=50,default='Not Extracted Yet')
    extractedIdNumber = models.CharField(max_length=30,default='Not Extracted Yet')
    extractedGender = models.CharField(max_length=15,default='Not Disclosed')
    extractedBirthYear = models.CharField(max_length=4,default='N/A')
    extractedBirthDate = models.TextField(default='N/A')
    to_be_reviewed = models.CharField(max_length=5,default='N/A')
    document_identification = models.TextField(default='NOT IDENTIFIED')
    DocCreatedDateTime = models.DateTimeField(auto_now_add=True)
    DocUpdatedDateTime = models.DateTimeField(auto_now_add=True)

    class Meta:
        UniqueConstraint(fields=['docId', 'userId','documentType'], name='UserDoc_Unique_Recordset')

    def __str__(self):
        return 'UserId:{}|DocType:{}|DocumentPath:{}'.format(self.userId,self.documentType,self.documentLoc)
