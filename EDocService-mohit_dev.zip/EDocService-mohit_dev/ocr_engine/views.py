import requests
from django.contrib import messages
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.views import View
from ocr_engine.models import UserDocuments
from useraccounts.models import UserProfileExtension


class ocrEngineView(View):

    def getUserAvatar(self, userID):
        UserAvatars = UserProfileExtension.objects.values('avatar').filter(user_id=userID)
        try:
            UserAvatar = UserAvatars[0].get('avatar')
        except:
            UserAvatar = 'avatar/default.png'
        return UserAvatar

    def getOcrData(self,reqPayload,request,docId):
        endpoint="https://1e66a0d6-659a-4ebc-b0f8-3f33787d01a6.mock.pstmn.io/documents_ml/v1/get_ocr_data"
        try:
            response=requests.request('POST',endpoint,data=reqPayload)
            respJson=response.json()
            if response.status_code == 200:
                if reqPayload.get('document_type') == 'aadhaar_front' and respJson.get('data').get('aadhaar_front').get('document_identification') == 'aadhaar_front':
                    extractedOcrData={
                                        'idHolderName' : respJson.get('data').get('aadhaar_front').get('name').get('value'),
                                        'idHolderGender' : respJson.get('data').get('aadhaar_front').get('gender').get('value'),
                                        'idHolderBirthYear': respJson.get('data').get('aadhaar_front').get('birth_year').get('value'),
                                        'idHolderBirthDate': respJson.get('data').get('aadhaar_front').get('date_of_birth').get('value','N/A'),
                                        'idHolderIdNumber': respJson.get('data').get('aadhaar_front').get('aadhaar_number').get('value'),
                                        'idHolderToBeReviewedStatus': respJson.get('data').get('aadhaar_front').get('to_be_reviewed').upper(),
                                        'idHolderDocIdentification': respJson.get('data').get('aadhaar_front').get('document_identification').upper(),
                                     }

                #Updating existing record in backend:
                ExtractedName=extractedOcrData.get('idHolderName')
                ExtractedIdNumber=extractedOcrData.get('idHolderIdNumber')
                ExtractedGender = extractedOcrData.get('idHolderGender')
                ExtractedBirthYear = extractedOcrData.get('idHolderBirthYear')
                ExtractedBirthDate = extractedOcrData.get('idHolderBirthDate')
                ExtractedRsReviewStatus = extractedOcrData.get('idHolderToBeReviewedStatus')
                ExtractedRsIdentify = extractedOcrData.get('idHolderDocIdentification')
                UserDocuments.objects.filter(userId=request.user.id,docId=docId).update(extractedName=ExtractedName,extractedIdNumber=ExtractedIdNumber,extractedGender=ExtractedGender,extractedBirthYear=ExtractedBirthYear,extractedBirthDate=ExtractedBirthDate,to_be_reviewed=ExtractedRsReviewStatus,document_identification=ExtractedRsIdentify)

            else:
                extractedOcrData={"status":"FAILURE"}
                print(respJson)

        except Exception as error:
            print(respJson)
            print(error)
            extractedOcrData={"status":"FAILURE"}
            messages.warning(request, "Failed to contact Server!")

        return extractedOcrData


    def uploadDocument(self,request):
        docType = request.POST.get('documentType')
        docLoc = request.FILES.get('documentLocation')
        user = User.objects.get(id=request.user.id)
        #print(docLoc)
        try:
            udocs = UserDocuments()
            udocs.userId=user
            udocs.documentType=docType
            udocs.documentLoc=docLoc
            udocs.save()
            messages.success(request, "User's {} has been successfully uploaded!".format(docType))

            #Data retrival post insertion for API call
            LatestInsertedRecordQs=UserDocuments.objects.filter(userId=request.user.id).values('docId','documentType','documentLoc').order_by('-DocUpdatedDateTime')[:1]
            #print(LatestInsertedRecordQs)
            #Setting up data inputs
            UploadedDocId = LatestInsertedRecordQs[0].get('docId')
            UploadedDocType = LatestInsertedRecordQs[0].get('documentType')
            UploadedDocPath = 'media/'+LatestInsertedRecordQs[0].get('documentLoc')

            #print(UploadedDocId,UploadedDocPath,UploadedDocType)
            #Preparing for API call:
            requestPayload={
                "file" : UploadedDocPath,
                "document_type" : UploadedDocType
            }

            parsedOcrResponse =  self.getOcrData(requestPayload,request,UploadedDocId)
            #print(parsedOcrResponse)

        except Exception as error:
            parsedOcrResponse={"status":"FAILURE"}
            messages.warning(request, "Failed to upload:{}".format(error))

        return parsedOcrResponse

    def get(self,request):
        if request.user.is_anonymous:
            return redirect('/login')
        UserAvatar = self.getUserAvatar(request.user.id)
        return render(request, 'document_upload.html', {'UserAvatar':UserAvatar})

    def post(self,request):
        if request.user.is_anonymous:
            return redirect('/login')
        UserAvatar = self.getUserAvatar(request.user.id)
        ocrExtract=self.uploadDocument(request)

        return render(request, 'document_upload.html', {'UserAvatar': UserAvatar,'ocrExtract':ocrExtract})








