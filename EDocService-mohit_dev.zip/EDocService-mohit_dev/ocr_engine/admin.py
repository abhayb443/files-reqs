from django.contrib import admin
from ocr_engine.models import UserDocuments
# Register your models here.
admin.site.register(UserDocuments)