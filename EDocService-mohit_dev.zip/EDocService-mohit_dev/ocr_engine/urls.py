from django.urls import path
from ocr_engine import views

urlpatterns = [
    path('', views.ocrEngineView.as_view(),name="document_upload"),

]