from django.contrib import admin
from fraud_detection.models import UserFraudDetection
# Register your models here.
admin.site.register(UserFraudDetection)