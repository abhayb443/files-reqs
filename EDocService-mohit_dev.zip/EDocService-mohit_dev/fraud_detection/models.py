from django.contrib.auth.models import User
from django.db import models
from django.db.models import UniqueConstraint


class UserFraudDetection(models.Model):
    FraudDetectionId = models.AutoField(primary_key=True)
    userId = models.ForeignKey(User,on_delete=models.CASCADE)
    ImgLoc = models.FileField(upload_to='uploaded_fraud_detection')
    FraudDetectionResult = models.CharField(max_length=25, default='NOT SET')
    NameMatchPercent = models.FloatField(default=0.0)
    FraudReviewReqdStatus = models.TextField(default='N/A')
    CreatedDateTime = models.DateTimeField(auto_now_add=True)

    class Meta:
        UniqueConstraint(fields=['FraudDetectionId', 'userId'], name='FraudDetection_Unique_Recordset')

    def __str__(self):
        return 'UserId:{}|Selfie:{}'.format(self.userId,self.ImgLoc)