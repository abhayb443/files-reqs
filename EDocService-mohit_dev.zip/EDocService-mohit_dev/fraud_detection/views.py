import requests
from django.contrib import messages
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.views import View
from fraud_detection.models import UserFraudDetection
from useraccounts.models import UserProfileExtension


class UserFraudDetectionView(View):

    def getUserAvatar(self, userID):
        UserAvatars = UserProfileExtension.objects.values('avatar').filter(user_id=userID)
        try:
            UserAvatar = UserAvatars[0].get('avatar')
        except:
            UserAvatar = 'avatar/default.png'
        return UserAvatar

    def performFraudDetection(self,reqPayload,request,fraudId):
        endpoint=" https://073a4e19-fa31-4104-bb4a-e802d0d7491b.mock.pstmn.io/api/v1/doc/fraud/detection"

        try:
            response = requests.request('GET', endpoint, data=reqPayload)
            respJson = response.json()
            if response.status_code == 200:
                fraudDoc = respJson.get('data').get('fraudalent_doc').upper()
                nameMatchPercent = respJson.get('data').get('name_match_percentage')
                reviewReqd  = respJson.get('data').get('to_be_reviewed').upper()

                fraudDetectionRs = {
                    'fraudDoc': fraudDoc,
                    'nameMatchPercent': nameMatchPercent,
                    'reviewReqd': reviewReqd
                }

                # Updating existing record in backend:
                UserFraudDetection.objects.filter(userId=request.user.id, FraudDetectionId=fraudId).update(FraudDetectionResult=fraudDoc,
                                                                                                      NameMatchPercent=nameMatchPercent,
                                                                                                      FraudReviewReqdStatus=reviewReqd)

            else:
                fraudDetectionRs = {"status": "FAILURE"}
                print(respJson)

        except Exception as error:
            print(respJson)
            print(error)
            fraudDetectionRs = {"status": "FAILURE"}
            messages.warning(request, "Failed to contact Server!")

        return fraudDetectionRs


    def FraudDetectionCheck(self,request):
        ImgLoc =  request.FILES.get('FraudDetectFile')
        user = User.objects.get(id=request.user.id)

        try:
            FraudDetectObj = UserFraudDetection()
            FraudDetectObj.userId = user
            FraudDetectObj.ImgLoc = ImgLoc
            FraudDetectObj.save()

            messages.success(request, "User's medial file has been successfully uploaded!")

            # Data retrival post insertion for API call
            LatestInsertedRecordValues = UserFraudDetection.objects.filter(userId=request.user.id).values('FraudDetectionId', 'ImgLoc').order_by('-CreatedDateTime')[:1]
            # Setting up data inputs
            UploadedFraudDetectId = LatestInsertedRecordValues[0].get('FraudDetectionId')
            UploadedMediaLoc = 'media/' + LatestInsertedRecordValues[0].get('ImgLoc')

            # Preparing for API call:
            requestPayload = {
                "file": UploadedMediaLoc
            }

            result=self.performFraudDetection(requestPayload,request,UploadedFraudDetectId)

        except Exception as error:
            messages.warning(request, "Failed to process data:{}".format(error))
            result = {"status": "FAILURE"}
        return result


    def get(self,request):
        if request.user.is_anonymous:
            return redirect('/login')
        UserAvatar = self.getUserAvatar(request.user.id)
        return render(request, 'fraud_detection.html', {'UserAvatar': UserAvatar})

    def post(self,request):
        if request.user.is_anonymous:
            return redirect('/login')
        UserAvatar = self.getUserAvatar(request.user.id)
        result = self.FraudDetectionCheck(request)
        return render(request, 'fraud_detection.html', {'UserAvatar': UserAvatar,'result':result})