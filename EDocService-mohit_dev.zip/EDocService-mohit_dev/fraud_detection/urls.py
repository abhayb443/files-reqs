from django.urls import path
from fraud_detection import views

urlpatterns = [
    path('', views.UserFraudDetectionView.as_view(),name="fraud_detection"),
]