from django.contrib.auth.models import User
from django.db import models
from django.db.models import UniqueConstraint


class UserDocumentClassification(models.Model):
    docId = models.AutoField(primary_key=True)
    userId = models.ForeignKey(User,on_delete=models.CASCADE)
    doc1Loc = models.FileField(upload_to='uploaded_doc_classification')
    docType = models.CharField(max_length=25, default='N/A')
    docNameMatchPercentage = models.FloatField(default=0.0)
    to_be_reviewed = models.TextField(default='N/A')
    DocCreatedDateTime = models.DateTimeField(auto_now_add=True)

    class Meta:
        UniqueConstraint(fields=['docId', 'userId'], name='DocumentClassification_Unique_Recordset')

    def __str__(self):
        return 'UserId:{}|DocLoc:{}'.format(self.userId,self.doc1Loc)
