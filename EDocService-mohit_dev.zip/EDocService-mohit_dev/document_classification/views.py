import requests
from django.contrib import messages
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.views import View
from document_classification.models import UserDocumentClassification
from useraccounts.models import UserProfileExtension


class UserDocumentClassificationView(View):

    def getUserAvatar(self, userID):
        UserAvatars = UserProfileExtension.objects.values('avatar').filter(user_id=userID)
        try:
            UserAvatar = UserAvatars[0].get('avatar')
        except:
            UserAvatar = 'avatar/default.png'
        return UserAvatar

    def performDocClassification(self,reqPayload,request,docId):
        endpoint = "https://073a4e19-fa31-4104-bb4a-e802d0d7491b.mock.pstmn.io/api/v1/doc/classification"
        try:
            response=requests.request('GET',endpoint,data=reqPayload)
            respJson = response.json()
            if response.status_code == 200:
                docType = respJson.get('data').get('document_type')
                nameMatchPercent = respJson.get('data').get('name_match_percentage')
                docClassifyReviewStatus = respJson.get('data').get('to_be_reviewed').upper()

                docClasssificationRs = {
                    'docType': docType,
                    'nameMatchPercent': nameMatchPercent,
                    'to_be_reviewed': docClassifyReviewStatus
                }

                # Updating existing record in backend:
                UserDocumentClassification.objects.filter(userId=request.user.id, docId=docId).update(docType=docType, docNameMatchPercentage=nameMatchPercent, to_be_reviewed=docClassifyReviewStatus)


            else:
                docClasssificationRs = {"status": "FAILURE"}
                print(respJson)

        except Exception as error:
            print(respJson)
            print(error)
            docClasssificationRs = {"status": "FAILURE"}
            messages.warning(request, "Failed to contact Server!")

        return docClasssificationRs

    def documentClassifier(self,request):
        Doc1 =  request.FILES.get('documentClassificationFile')
        user = User.objects.get(id=request.user.id)

        try:
            DocClassificationObj = UserDocumentClassification()
            DocClassificationObj.userId = user
            DocClassificationObj.doc1Loc = Doc1
            DocClassificationObj.save()

            messages.success(request, "User's document has been successfully uploaded!")

            # Data retrival post insertion for API call
            LatestInsertedRecordValues = UserDocumentClassification.objects.filter(userId=request.user.id).values('docId','doc1Loc').order_by('-DocCreatedDateTime')[:1]
            # Setting up data inputs
            UploadedDocClassificationId = LatestInsertedRecordValues[0].get('docId')
            UploadedDocLoc = 'media/' + LatestInsertedRecordValues[0].get('doc1Loc')

            # Preparing for API call:
            requestPayload = {
                "file": UploadedDocLoc
            }

            result = self.performDocClassification(requestPayload,request,UploadedDocClassificationId)


        except Exception as error:
            messages.warning(request, "Failed to process data:{}".format(error))
            result= {"status": "FAILURE"}
        return result


    def get(self,request):
        if request.user.is_anonymous:
            return redirect('/login')
        UserAvatar = self.getUserAvatar(request.user.id)
        return render(request, 'document_classification.html', {'UserAvatar': UserAvatar})

    def post(self,request):
        if request.user.is_anonymous:
            return redirect('/login')
        UserAvatar = self.getUserAvatar(request.user.id)
        result = self.documentClassifier(request)
        return render(request, 'document_classification.html', {'UserAvatar': UserAvatar,'result':result})