from django.contrib import admin
from document_classification.models import UserDocumentClassification
# Register your models here.
admin.site.register(UserDocumentClassification)