from django.urls import path
from document_classification import views

urlpatterns = [
    path('', views.UserDocumentClassificationView.as_view(),name="document_classification"),
]