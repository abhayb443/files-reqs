from django.urls import path
from useraccounts import views

urlpatterns = [
    path('', views.loginUser,name="login"),
    path('login', views.loginUser,name="login"),
    path('register', views.registerUser,name="register"),
    path('changepassword', views.changeUserPassword,name="changepassword"),
    path('edituserprofile',views.editUserProfile,name='edituserprofile'),
    path('logout', views.logoutUser,name="logout"),
    path('dashboard', views.userDashboard,name="dashboard"),

]