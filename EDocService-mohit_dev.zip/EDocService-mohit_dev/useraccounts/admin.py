from django.contrib import admin
from useraccounts.models import UserProfileExtension
# Register your models here.
admin.site.register(UserProfileExtension)