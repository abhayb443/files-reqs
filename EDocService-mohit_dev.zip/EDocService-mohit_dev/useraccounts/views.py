import datetime
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, redirect
from useraccounts.models import UserProfileExtension


def registerUser(request):
    print(request.method)
    if request.method == 'POST':
        uname = request.POST.get('username')
        email = request.POST.get('email')
        paswd = request.POST.get('password')
        fname = request.POST.get('firstname')
        lname = request.POST.get('lastname')
        avatar = request.FILES.get('profileimage')

        # Validation to check incorporation of First and Last Name
        if fname in ['', None] or lname in ['', None]:
            messages.info(request, 'Kindly provide Firstname and Lastname as per your JIRA account.')
            return redirect('/register')

        elif uname in ['', None]:
            messages.info(request, 'Username cannot be empty, kindly provide a valid username.')
            return redirect('/register')

        if avatar in ['', None]:
            avatar = 'avatar/default.png'

        # Logic for checking existing Username
        ExistingUsers = User.objects.values('username').filter(username=uname).count()
        ExistingEmails = User.objects.values('email').filter(email=email).count()
        # print('len:'+str(ExistingUsers))
        if ExistingUsers == 0 and ExistingEmails == 0:
            # Creating New User
            user = User.objects.create_user(uname, email, paswd)
            # Adding additional Attributes
            user.first_name = fname
            user.last_name = lname
            user.save()
            userprofile = UserProfileExtension()
            userprofile.user_id = user.id
            userprofile.avatar = avatar
            userprofile.save()
            messages.success(request, 'User has been created successfully in the system!')

        else:
            messages.warning(request,'Username: ' + uname + ' or Email:' + email + ' is already taken, please try something else.')
            return redirect('/register')
        return redirect('/login')
    return render(request, 'register.html')

def loginUser(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        # Authenticate User
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('/dashboard')
        else:
            messages.warning(request, 'Invalid credentials!')
            return render(request, 'login.html')

    return render(request, 'login.html')

def changeUserPassword(request):
    if request.user.is_anonymous:
        return redirect('/login')

    # Logic for User Image
    UserAvatars = UserProfileExtension.objects.values('avatar').filter(user_id=request.user.id)
    try:
        UserAvatar = UserAvatars[0].get('avatar')
    except:
        UserAvatar = 'avatar/default.png'

    if request.method == 'POST':
        changedPass = request.POST.get('newpassword')
        confirmPass = request.POST.get('confirmpassword')
        if changedPass == confirmPass and (changedPass not in ['', None] and confirmPass not in ['', None]):
            user = User.objects.get(username=request.user)
            user.set_password(changedPass)
            user.save()
            messages.success(request, 'Password successfully updated for ' + str(request.user) + '!')
        else:
            messages.warning(request, 'New password and confirmed password dont match!')

    return render(request, 'changepassword.html', {'UserAvatar': UserAvatar})

def editUserProfile(request):
    if request.user.is_anonymous:
        return redirect('/login')

    #Logic for User Image
    UserAvatars = UserProfileExtension.objects.values('avatar').filter(user_id=request.user.id)
    try:
        UserAvatar = UserAvatars[0].get('avatar')
    except:
        UserAvatar = 'avatar/default.png'

    if request.method == 'POST':
        updEmail=request.POST.get('updemail')
        updFname = request.POST.get('updfirstname')
        updLname = request.POST.get('updlastname')
        updAvatar = request.FILES.get('updprofileimage')

        #Fetching Existing User
        user = User.objects.get(username=request.user)
        if user is not None:
            if updFname not in ['',None]:user.first_name = updFname
            if updLname not in ['',None]:user.last_name = updLname
            if updEmail not in ['',None]:user.email=updEmail
            user.save()
            if updAvatar not in ['',None]:
               #If record unavailable then insert new
               if UserProfileExtension.objects.filter(user_id=user.id).count() == 0:
                   userprofile = UserProfileExtension()
                   userprofile.user_id = user.id
                   userprofile.avatar = updAvatar
                   userprofile.save()
               else:
                    #Filestoring logic on update
                    fs = FileSystemStorage()
                    filename = fs.save('avatar/' + updAvatar.name, updAvatar)
                    uploaded_avatar_url = fs.url(filename)
                    strtPos = uploaded_avatar_url.find('/', 2) + 1
                    UserProfileExtension.objects.filter(user_id=user.id).update(avatar=uploaded_avatar_url[strtPos:])

            messages.success(request, 'Profile details successfully updated for ' + str(request.user) + '!')
        else:
            messages.warning(request, 'Profile details were not updated for ' + str(request.user) + '!')

    return render(request,'edituserprofile.html',{'UserAvatar': UserAvatar})

def logoutUser(request):
    logout(request)
    return render(request, 'login.html')

def userDashboard(request):
    if request.user.is_anonymous:
        return redirect('/login')
    current_time = datetime.datetime.now()
    HourOfDay = current_time.hour
    if request.method == 'GET':
        if HourOfDay < 12:
            greet = 'Good Morning'
        elif HourOfDay > 12 and HourOfDay < 16:
            greet = 'Good Afternoon'
        else:
            greet = 'Good Evening'

    UserAvatars = UserProfileExtension.objects.values('avatar').filter(user_id=request.user.id)
    try:
        UserAvatar = UserAvatars[0].get('avatar')
    except:
        UserAvatar = 'avatar/default.png'

    return render(request,'dashboard.html',{'greet':greet,'UserAvatar':UserAvatar})





