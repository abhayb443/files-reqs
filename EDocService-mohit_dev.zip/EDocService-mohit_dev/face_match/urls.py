from django.urls import path
from face_match import views

urlpatterns = [
    path('', views.UserFaceMatchView.as_view(),name="face_match"),
]