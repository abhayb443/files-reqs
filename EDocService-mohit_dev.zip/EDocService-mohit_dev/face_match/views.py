import requests
from django.contrib import messages
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.views import View
from face_match.models import UserFaceMatch
from useraccounts.models import UserProfileExtension


class UserFaceMatchView(View):

    def getUserAvatar(self, userID):
        UserAvatars = UserProfileExtension.objects.values('avatar').filter(user_id=userID)
        try:
            UserAvatar = UserAvatars[0].get('avatar')
        except:
            UserAvatar = 'avatar/default.png'
        return UserAvatar

    def performFaceMatch(self,reqPayload,request,fmId):
        endpoint ="https://1e66a0d6-659a-4ebc-b0f8-3f33787d01a6.mock.pstmn.io/documents_ml/v1/face_verify"
        try:
            response=requests.request('POST',endpoint,data=reqPayload)
            respJson=response.json()
            if response.status_code == 200:
               if respJson.get('data').get('match-status') == 'yes':
                   faceMatchResult = 'FACE MATCHED'
               else:
                   faceMatchResult = 'FACE NOT MATCHED'
               faceMatchScore = respJson.get('data').get('match-score')
               faceMatchConfidence =respJson.get('data').get('confidence')
               faceMatchReviewStatus = respJson.get('data').get('to-be-reviewed').upper()

               faceMatchResultSet ={
                                    'faceMatchResult':faceMatchResult,
                                    'faceMatchConfidence':faceMatchConfidence,
                                    'faceMatchScore':faceMatchScore,
                                    'faceMatchReviewStatus':faceMatchReviewStatus
                                   }

               #Updating existing record in backend:
               UserFaceMatch.objects.filter(userId=request.user.id,faceMatchId=fmId).update(faceMatchResult=faceMatchResult,faceMatchScore=faceMatchScore,faceMatchConfidence=faceMatchConfidence,to_be_reviewed=faceMatchReviewStatus)

            else:
                faceMatchResultSet={"status":"FAILURE"}
                print(respJson)

        except Exception as error:
            print(respJson)
            print(error)
            faceMatchResultSet={"status":"FAILURE"}
            messages.warning(request, "Failed to contact Server!")

        return faceMatchResultSet


    def FaceMatcher(self,request):
        DocLoc =  request.FILES.get('FaceMatchFile')
        Selfie =  request.FILES.get('FaceMatchSelfie')
        user = User.objects.get(id=request.user.id)

        try:
            FaceMatchObj = UserFaceMatch()
            FaceMatchObj.userId = user
            FaceMatchObj.docLoc = DocLoc
            FaceMatchObj.selfieLoc = Selfie
            #FaceMatchObj.faceMatchResult=''
            FaceMatchObj.save()

            messages.success(request, "User's documents have been successfully uploaded!")

            #Data retrival post insertion for API call
            LatestInsertedRecordValues = UserFaceMatch.objects.filter(userId=request.user.id).values('faceMatchId','docLoc','selfieLoc').order_by('-CreatedDateTime')[:1]
            # print(LatestInsertedRecordValues)
            # Setting up data inputs
            UploadedFaceMatchId = LatestInsertedRecordValues[0].get('faceMatchId')
            UploadedDocLoc = 'media/'+LatestInsertedRecordValues[0].get('docLoc')
            UploadedSelfieLoc = 'media/'+LatestInsertedRecordValues[0].get('selfieLoc')

            print(UploadedFaceMatchId,UploadedDocLoc,UploadedSelfieLoc)
            # Preparing for API call:
            requestPayload = {
                "selfie": UploadedSelfieLoc,
                "id_proof": UploadedDocLoc
            }
            faceMatchResponse = self.performFaceMatch(requestPayload,request,UploadedFaceMatchId)

        except Exception as error:
            messages.warning(request, "Failed to process data:{}".format(error))
            faceMatchResponse={"status": "FAILURE"}

        return faceMatchResponse


    def get(self,request):
        if request.user.is_anonymous:
            return redirect('/login')
        UserAvatar = self.getUserAvatar(request.user.id)
        return render(request, 'face_match.html', {'UserAvatar': UserAvatar})

    def post(self,request):
        if request.user.is_anonymous:
            return redirect('/login')
        UserAvatar = self.getUserAvatar(request.user.id)
        result = self.FaceMatcher(request)
        return render(request, 'face_match.html', {'UserAvatar': UserAvatar,'result':result})