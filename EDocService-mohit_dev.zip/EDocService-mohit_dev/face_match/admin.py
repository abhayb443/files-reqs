from django.contrib import admin
from face_match.models import UserFaceMatch
# Register your models here.
admin.site.register(UserFaceMatch)