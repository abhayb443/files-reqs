from django.contrib.auth.models import User
from django.db import models
from django.db.models import UniqueConstraint


class UserFaceMatch(models.Model):
    faceMatchId = models.AutoField(primary_key=True)
    userId = models.ForeignKey(User,on_delete=models.CASCADE)
    docLoc = models.FileField(upload_to='uploaded_face_match/face_match_doc')
    selfieLoc = models.ImageField(upload_to='uploaded_face_match/face_match_selfie')
    faceMatchResult = models.CharField(max_length=25, default='NOT SET')
    faceMatchScore = models.IntegerField(default=0)
    faceMatchConfidence = models.FloatField(default=0.0)
    to_be_reviewed = models.TextField(default='N/A')
    CreatedDateTime = models.DateTimeField(auto_now_add=True)

    class Meta:
        UniqueConstraint(fields=['faceMatchId', 'userId'], name='FaceMatch_Unique_Recordset')

    def __str__(self):
        return 'UserId:{}|Doc:{}|Selfie:{}'.format(self.userId,self.doc1Loc,self.selfieLoc)
